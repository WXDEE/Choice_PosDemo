package com.choice.common;

public class Const {
    public static final String DHSI_NUM = "5";
    public static final String DISH_CACHE = "dishcache";
}